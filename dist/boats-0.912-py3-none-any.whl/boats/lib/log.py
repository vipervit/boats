import datetime
import json
import os
import time
import warnings
from datetime import datetime
from datetime import timedelta
from io import StringIO

import pandas as pd
import pytz
from geopy import distance

from boats import DIR_LOGS, DIR_TEST_FILES, DATETIME_FORMAT
from boats.lib.common import make_log_file_name, miles_to_nautical, calc_total_voyage_days, calc_total_voyage_distance


class Log:

    def __init__(self, boat_name, allownew=False):
        self._allownew = allownew
        warnings.simplefilter(action='ignore', category=FutureWarning)
        location = DIR_LOGS
        if not __debug__:  # the logic is inverted; to run  in debug mode '-O' must be used
            location = DIR_TEST_FILES
        self._file = os.path.join(location, make_log_file_name(boat_name))
        self._track = None
        self._df = None
        self.load()

    @property
    def myfile(self):
        return self._file

    @property
    def track(self):
        return self._track

    @property
    def allow_new(self):
        return self._allownew

    @allow_new.setter
    def allow_new(self, val):
        self._allownew = val

    @staticmethod
    def required_columns():
        return ['hdg',
                'tws',
                'spd',
                'twd',
                'twa',
                'heel',
                'lat',
                'lon',
                'sails']

    def load(self):
        if self.__exists__():
            self.__make_df__()
            self.__get_track__()
            return True
        else:
            if self.allow_new:
                return False
            else:
                raise FileNotFoundError(f'Log file not found: {self._file}! (Note: \'allow_new\' is {self.allow_new}.)')

    def add_new(self, newrec):
        data = {}
        assert list(newrec.keys()) == self.required_columns()
        if self.__exists__():
            data = self.__read_from_file__()
        data.update({str(time.time()): newrec})
        self.__write_to_file__(data)

    @property
    def df(self):
        return self._df

    @property
    def last_record(self):
        return self._df.iloc[-1]

    @property
    def last_position(self):
        return [self.last_record['lat'], self.last_record['lon']]

    @property
    def last_record_timestamp(self):
        return self.last_record.name.timestamp()

    @property
    def last_record_timestamp_local(self):
        return datetime.fromtimestamp(self.last_record_timestamp).astimezone(pytz.timezone('US/Eastern')) \
            .strftime(DATETIME_FORMAT)

    @property
    def last_24_hrs_distance(self):
        df = self.df
        hrs_24 = df.index[-1] - timedelta(days=1)
        df_24hrs = df[df.index.isin([entry for entry in df.index if entry >= hrs_24])]
        start_pos = list(df_24hrs.iloc[0][['lat', 'lon']].values)
        last_pos = list(df_24hrs.iloc[-1][['lat', 'lon']].values)
        return round(miles_to_nautical(distance.distance(start_pos, last_pos).miles))

    @property
    def last_24_hrs_average_speed(self):
        return round(self.last_24_hrs_distance / 24, 1)

    @property
    def total_days(self):
        return calc_total_voyage_days(self.df.index[0], self.df.index[-1])

    @property
    def total_distance(self):
        return calc_total_voyage_distance(self.df[['lat', 'lon']])

    def __exists__(self):
        res = os.path.exists(self._file)
        if not res:
            warnings.warn(f'Log file not found: {self._file}.')
        return res

    def __get_track__(self):
        if self._df is not None:
            df = self._df.copy()
            df.sort_index(ascending=False, inplace=True)
            df_track = df[['lat', 'lon']].dropna()
            self._track = [[df_track.loc[i, 'lat'], df_track.loc[i, 'lon']] for i in df_track.index]
        else:
            raise ValueError('self._df is None.')

    def __make_df__(self):
        self._df = pd.read_json(StringIO(json.dumps(self.__read_from_file__())), orient='index')

    def __read_from_file__(self):
        try:
            with open(self._file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f'Log file does not exist: \'{self._file}\'.')

    def __write_to_file__(self, dic):
        with open(self._file, 'w') as f:
            json.dump(dic, f)

    def __delete_file__(self):
        os.remove(self._file)
